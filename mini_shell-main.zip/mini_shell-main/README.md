# mini_shell
Mini Shell project of 42.
